/* 115210597 - Victor Eduardo Borges de Araujo: LAB 7 - Turma 3 */

package excecoes;

public class StringInvalidaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StringInvalidaException(String msg) {
		super(msg);
	}

}
