/* 115210597 - Victor Eduardo Borges de Araujo: LAB 7 - Turma 3 */

package excecoes;

public class PrecoInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PrecoInvalidoException(String msg) {
		super(msg);
	}

}
