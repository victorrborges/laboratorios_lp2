/* 115210597 - Victor Eduardo Borges de Araujo: LAB 7 - Turma 3 */

package excecoes;

public class ValorInvalidoException extends PrecoInvalidoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValorInvalidoException(String msg) {
		super(msg);
	}

}
