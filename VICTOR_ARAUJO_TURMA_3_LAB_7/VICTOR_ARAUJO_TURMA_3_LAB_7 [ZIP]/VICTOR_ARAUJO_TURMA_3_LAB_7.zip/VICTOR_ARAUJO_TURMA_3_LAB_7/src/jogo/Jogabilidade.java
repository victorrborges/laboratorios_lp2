/* 115210597 - Victor Eduardo Borges de Araujo: LAB 7 - Turma 3 */

package jogo;

/** Essa classe representa o objeto Jogabilidade.
 * @author Victor Borges
 */
public enum Jogabilidade {
	
	ONLINE, OFFLINE, MULTIPLAYER,COOPERATIVO, COMPETITIVO; 

}
