/* 115210597 - Victor Eduardo Borges de Araujo: LAB 3 - Turma 3 */

package economiza_p2;

public class Main {
	
	public static void main(String[] args) {
		
		MenuDeEntrada menu = new MenuDeEntrada();
		
		menu.menuPrincipal();
		
	}

}
