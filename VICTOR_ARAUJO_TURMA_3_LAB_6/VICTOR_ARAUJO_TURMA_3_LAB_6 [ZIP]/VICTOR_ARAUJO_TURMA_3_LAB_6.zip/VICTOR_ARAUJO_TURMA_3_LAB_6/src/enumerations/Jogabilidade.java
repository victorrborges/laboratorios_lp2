/* 115210597 - Victor Eduardo Borges de Araujo: LAB 6 - Turma 3 */

package enumerations;

/** Essa classe representa o objeto Jogabilidade.
 * @author Victor Borges
 */
public enum Jogabilidade {
	ONLINE, OFFLINE, MULTIPLAYER, COOPERATIVO, COMPETITIVO;
}
